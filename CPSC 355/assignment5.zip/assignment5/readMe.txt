Name: Daniel Jin
UCID: 30107081
Assignment 5



How to use:
This programs uses command line input in oder to make a square matrix, with each element generated randomly from 0 to 9.
The user can then choose to sort any of the columns from 0 to one less from the inputed integer. 
The user can choose to sort one or more columns until 111 is inputed to quit the software. 



Description about sort function:
This function impliments a bubble sort method. This is where the integer on the left of the array compares to the one on the right, 
if the left if greater than the integer on the right, then it will swap places, and so on until its in order.

The swap method gets two parameters(a,b). It assigns (b) to a temporary variable (c), and (b) is assigned as (a), (so b = a). Now (a) is assigned to (c) (a = c) where (c) kept (b)'s previous value. However this implimentation
was coded into one sort function.

With these two methods the sort function was made.
This code was from: https://www.geeksforgeeks.org/bubble-sort/